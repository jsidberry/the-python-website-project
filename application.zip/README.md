# the-python-website-project
Building a website using Python programming language and Flask as a the web-framework.

Goal is to build a functional website that is maintainable. 